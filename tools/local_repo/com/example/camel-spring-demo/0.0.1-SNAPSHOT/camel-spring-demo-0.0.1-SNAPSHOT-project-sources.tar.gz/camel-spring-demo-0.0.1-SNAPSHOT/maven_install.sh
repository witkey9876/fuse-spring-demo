# maven install path
tools/apache-maven-3.5.0/bin/mvn clean install -Dmaven.repo.local=tools/local_repo/ -Dsource=8