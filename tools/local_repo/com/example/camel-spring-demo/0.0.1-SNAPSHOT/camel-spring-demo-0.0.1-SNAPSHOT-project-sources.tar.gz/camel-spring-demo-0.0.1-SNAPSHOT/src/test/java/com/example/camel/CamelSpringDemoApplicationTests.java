package com.example.camel;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamelSpringDemoApplicationTests {

    void contextLoads() {
    }

}
